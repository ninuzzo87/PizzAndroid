# Dough Pizza Android — versione 2.0

Progetto sorgente nativo Android in Kotlin + Jetpack Compose, in italiano.

## Funzioni
- Calcolatore ingredienti in grammi con percentuali da fornaio
- Preset: napoletana, New York, teglia/romana, pan pizza e personalizzato
- Pianificazione della fermentazione a temperatura ambiente o in frigorifero
- Calcolatore Poolish con ripartizione di farina, acqua e lievito
- Ricette salvate sul dispositivo tramite SharedPreferences
- Timer con avvio, pausa, riavvio e azzeramento mentre l'app resta aperta
- Calcolo della temperatura acqua secondo una formula DDT semplificata a tre fattori

## Compilazione
1. Estrai questo ZIP.
2. Apri la cartella `DoughPizzaAndroid_v2` in Android Studio.
3. Attendi Gradle Sync e installa Android SDK 35 se richiesto.
4. Collega un telefono Android con Debug USB oppure avvia un emulatore.
5. Premi Run per installare.

## Limiti da conoscere
- Questo è il progetto sorgente, non un APK compilato.
- Il timer non usa un servizio in background e non invia notifiche se l'app viene chiusa.
- La fermentazione è una pianificazione manuale: la dose di lievito non viene dedotta automaticamente dalle ore/temperatura perché dipende da ricetta, farina, lievito e condizioni reali.
- Il Poolish è un calcolatore di ripartizione delle quantità totali; le percentuali sono regolabili.
- Il DDT mostrato usa una formula semplificata per impasto diretto a tre fattori; prefermenti e diverse configurazioni richiedono un calcolo adattato.
- Il codice non è affiliato a DoughMetry e non include codice o risorse proprietarie del sito.
