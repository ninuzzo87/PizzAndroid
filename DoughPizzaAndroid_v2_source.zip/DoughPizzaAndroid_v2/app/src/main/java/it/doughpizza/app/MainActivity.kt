package it.doughpizza.app

import android.os.Bundle
import android.content.Context
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import kotlin.math.roundToInt

private val bg = Color(0xFFF7F3EC)
private val ink = Color(0xFF24221F)
private val red = Color(0xFFB8442B)
private val cardColor = Color.White

private data class Style(val name: String, val hydration: Float, val salt: Float, val oil: Float, val yeast: Float, val note: String)
private val styles = listOf(
    Style("Napoletana", 62f, 2.8f, 0f, 0.10f, "Bordo sviluppato e impasto morbido."),
    Style("New York", 63f, 2.5f, 2f, 0.12f, "Base flessibile, adatta anche al forno domestico."),
    Style("Teglia / Romana", 75f, 2.5f, 2f, 0.10f, "Idratazione elevata e mollica aperta."),
    Style("Pan pizza", 68f, 2.3f, 4f, 0.12f, "Più soffice e ricca."),
    Style("Personalizzato", 62f, 2.5f, 0f, 0.10f, "Imposta le percentuali della tua ricetta.")
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { DoughPizzaApp(applicationContext) }
    }
}

@Composable
private fun DoughPizzaApp(context: Context) {
    var tab by remember { mutableStateOf("Impasto") }
    var styleIndex by remember { mutableIntStateOf(0) }
    var balls by remember { mutableStateOf("4") }
    var ballWeight by remember { mutableStateOf("250") }
    var hydration by remember { mutableStateOf("62") }
    var salt by remember { mutableStateOf("2.8") }
    var oil by remember { mutableStateOf("0") }
    var yeast by remember { mutableStateOf("0.10") }
    var yeastType by remember { mutableStateOf("Secco istantaneo") }
    var hours by remember { mutableStateOf("24") }
    var temp by remember { mutableStateOf("20") }
    var fridge by remember { mutableStateOf(false) }
    var poolishPct by remember { mutableStateOf("30") }
    var poolishHydration by remember { mutableStateOf("100") }
    var poolishHours by remember { mutableStateOf("12") }
    var poolishYeast by remember { mutableStateOf("0.1") }
    var waterTemp by remember { mutableStateOf("20") }
    var flourTemp by remember { mutableStateOf("22") }
    var roomTemp by remember { mutableStateOf("22") }
    var friction by remember { mutableStateOf("4") }
    var targetDdt by remember { mutableStateOf("24") }
    var recipeName by remember { mutableStateOf("La mia pizza") }
    var recipes by remember { mutableStateOf(loadRecipes(context)) }
    var timerMinutes by remember { mutableStateOf("30") }
    var remaining by remember { mutableLongStateOf(0L) }
    var timerRunning by remember { mutableStateOf(false) }
    var timerLabel by remember { mutableStateOf("Riposo impasto") }
    var message by remember { mutableStateOf("") }

    LaunchedEffect(styleIndex) {
        val st = styles[styleIndex]
        hydration = st.hydration.toString()
        salt = st.salt.toString()
        oil = st.oil.toString()
        yeast = st.yeast.toString()
    }
    LaunchedEffect(timerRunning) {
        while (timerRunning && remaining > 0L) {
            delay(1000L)
            remaining -= 1L
            if (remaining <= 0L) {
                timerRunning = false
                message = "Timer completato: $timerLabel"
            }
        }
    }

    val n = (balls.toFloatOrNull() ?: 4f).coerceIn(1f, 200f)
    val w = (ballWeight.toFloatOrNull() ?: 250f).coerceIn(1f, 5000f)
    val h = (hydration.toFloatOrNull() ?: 62f).coerceIn(0f, 150f)
    val s = (salt.toFloatOrNull() ?: 2.8f).coerceIn(0f, 20f)
    val o = (oil.toFloatOrNull() ?: 0f).coerceIn(0f, 30f)
    val y = (yeast.toFloatOrNull() ?: 0.1f).coerceIn(0f, 10f)
    val doughWeight = n * w
    val flour = doughWeight / (1f + (h + s + o + y) / 100f)
    val water = flour * h / 100f
    val saltG = flour * s / 100f
    val oilG = flour * o / 100f
    val yeastG = flour * y / 100f
    val actualTotal = flour + water + saltG + oilG + yeastG
    val poolPct = (poolishPct.toFloatOrNull() ?: 30f).coerceIn(0f, 100f)
    val poolHyd = (poolishHydration.toFloatOrNull() ?: 100f).coerceIn(0f, 150f)
    val poolFlour = flour * poolPct / 100f
    val poolWater = poolFlour * poolHyd / 100f
    val poolYeastG = poolFlour * (poolishYeast.toFloatOrNull() ?: 0.1f).coerceIn(0f, 5f) / 100f
    val ddt = 3f * (targetDdt.toFloatOrNull() ?: 24f) - (flourTemp.toFloatOrNull() ?: 22f) - (roomTemp.toFloatOrNull() ?: 22f) - (friction.toFloatOrNull() ?: 4f)

    MaterialTheme(colorScheme = lightColorScheme(primary = red, background = bg, surface = cardColor, onBackground = ink, onSurface = ink)) {
        Column(Modifier.fillMaxSize().background(bg)) {
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Box(Modifier.size(52.dp).background(red, RoundedCornerShape(16.dp)), contentAlignment = Alignment.Center) { Text("🍕", fontSize = 28.sp) }
                    Column {
                        Text("DOUGH PIZZA", fontSize = 24.sp, fontWeight = FontWeight.Black, color = ink)
                        Text("Versione 2.0 · il laboratorio dell'impasto", fontSize = 12.sp, color = Color.DarkGray)
                    }
                }
                if (message.isNotBlank()) {
                    Card(colors = CardDefaults.cardColors(containerColor = Color(0xFFFFE8D6))) {
                        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(message, Modifier.weight(1f), color = ink)
                            TextButton(onClick = { message = "" }) { Text("OK") }
                        }
                    }
                }
                when (tab) {
                    "Impasto" -> {
                        CardBlock {
                            Text("1 · Stile di pizza", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                            styles.forEachIndexed { i, st ->
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    RadioButton(selected = styleIndex == i, onClick = { styleIndex = i })
                                    Column {
                                        Text(st.name, fontWeight = FontWeight.SemiBold)
                                        Text(st.note, fontSize = 12.sp, color = Color.Gray)
                                    }
                                }
                            }
                        }
                        CardBlock {
                            Text("2 · Numero e peso dei panetti", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                NumberField("Panetti", balls, { balls = it }, Modifier.weight(1f))
                                NumberField("Peso panetto (g)", ballWeight, { ballWeight = it }, Modifier.weight(1f))
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf("200", "250", "280", "300").forEach { preset ->
                                    OutlinedButton(onClick = { ballWeight = preset }, contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)) { Text("${preset}g") }
                                }
                            }
                        }
                        CardBlock {
                            Text("3 · Percentuali da fornaio", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                            Text("Farina = 100%. Modifica le percentuali in base alla tua ricetta.", fontSize = 12.sp, color = Color.Gray)
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                NumberField("Idratazione %", hydration, { hydration = it }, Modifier.weight(1f))
                                NumberField("Sale %", salt, { salt = it }, Modifier.weight(1f))
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                NumberField("Olio %", oil, { oil = it }, Modifier.weight(1f))
                                NumberField("Lievito %", yeast, { yeast = it }, Modifier.weight(1f))
                            }
                            Text("Tipo di lievito", fontWeight = FontWeight.Medium)
                            SimpleDropdown(yeastType, listOf("Secco istantaneo", "Secco attivo", "Fresco")) { yeastType = it }
                            IngredientRow("Farina", flour, "100%")
                            IngredientRow("Acqua", water, "${fmt(h)}%")
                            IngredientRow("Sale", saltG, "${fmt(s)}%")
                            if (o > 0) IngredientRow("Olio", oilG, "${fmt(o)}%")
                            IngredientRow("Lievito ($yeastType)", yeastG, "${fmt(y)}%")
                            Divider()
                            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Totale stimato", fontWeight = FontWeight.Bold)
                                Text("${fmt(actualTotal)} g", color = red, fontWeight = FontWeight.Black, fontSize = 20.sp)
                            }
                        }
                        CardBlock {
                            Text("4 · Lievitazione", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                NumberField("Ore totali", hours, { hours = it }, Modifier.weight(1f))
                                NumberField("Temperatura °C", temp, { temp = it }, Modifier.weight(1f))
                            }
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Switch(checked = fridge, onCheckedChange = { fridge = it })
                                Text(if (fridge) "Frigorifero" else "Temperatura ambiente")
                            }
                            Text("Promemoria: ${hours.ifBlank { "0" }} ore · ${temp.ifBlank { "20" }} °C · ${if (fridge) "freddo" else "ambiente"}", color = Color.Gray, fontSize = 13.sp)
                            Text("La dose di lievito è modificabile manualmente: tempi e temperatura non bastano da soli a prevedere la maturazione.", fontSize = 12.sp, color = Color.Gray)
                        }
                    }
                    "Poolish" -> {
                        CardBlock {
                            Text("Calcolatore Poolish", fontSize = 21.sp, fontWeight = FontWeight.Black, color = red)
                            Text("Il poolish è un preimpasto generalmente a pari peso di farina e acqua. Imposta le percentuali per la tua ricetta.")
                            NumberField("Farina nel poolish (% della farina totale)", poolishPct, { poolishPct = it })
                            NumberField("Idratazione poolish %", poolishHydration, { poolishHydration = it })
                            NumberField("Lievito poolish % sulla farina del poolish", poolishYeast, { poolishYeast = it })
                            NumberField("Ore previste", poolishHours, { poolishHours = it })
                            Divider()
                            IngredientRow("Farina poolish", poolFlour, "${fmt(poolPct)}% della farina totale")
                            IngredientRow("Acqua poolish", poolWater, "${fmt(poolHyd)}%")
                            IngredientRow("Lievito poolish", poolYeastG, "sulla farina poolish")
                            IngredientRow("Farina da aggiungere dopo", flour - poolFlour, "completamento impasto")
                            IngredientRow("Acqua da aggiungere dopo", water - poolWater, "acqua residua stimata")
                            Text("Nota: il poolish non va sommato due volte. Questi ingredienti sono una ripartizione delle quantità totali calcolate nella scheda Impasto.", fontSize = 12.sp, color = Color.Gray)
                        }
                        CardBlock {
                            Text("Indicazioni pratiche", fontSize = 18.sp, fontWeight = FontWeight.Bold)
                            Text("• Usa un contenitore capiente e segna il livello iniziale.")
                            Text("• Considera il poolish pronto quando è pieno di bolle e la superficie inizia appena ad appiattirsi.")
                            Text("• La maturazione dipende molto dalla temperatura e dalla dose di lievito.")
                        }
                    }
                    "Ricette" -> {
                        CardBlock {
                            Text("Le mie ricette", fontSize = 21.sp, fontWeight = FontWeight.Black, color = red)
                            NumberField("Nome ricetta", recipeName, { recipeName = it })
                            Button(onClick = {
                                val obj = JSONObject()
                                    .put("name", recipeName.ifBlank { "Ricetta senza nome" })
                                    .put("style", styles[styleIndex].name)
                                    .put("balls", balls).put("weight", ballWeight)
                                    .put("hydration", hydration).put("salt", salt).put("oil", oil).put("yeast", yeast)
                                    .put("hours", hours).put("temp", temp).put("fridge", fridge)
                                val updated = (recipes.filterNot { it.optString("name") == obj.optString("name") } + obj)
                                recipes = updated
                                saveRecipes(context, updated)
                                message = "Ricetta salvata: ${obj.optString("name")}"
                            }, modifier = Modifier.fillMaxWidth()) { Text("Salva ricetta corrente") }
                            if (recipes.isEmpty()) Text("Non hai ancora salvato ricette.")
                            recipes.forEach { recipe ->
                                HorizontalDivider()
                                Text(recipe.optString("name"), fontWeight = FontWeight.Bold, fontSize = 17.sp)
                                Text("${recipe.optString("style")} · ${recipe.optString("balls")} panetti da ${recipe.optString("weight")} g · idratazione ${recipe.optString("hydration")}%", fontSize = 13.sp)
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(onClick = {
                                        balls = recipe.optString("balls", "4"); ballWeight = recipe.optString("weight", "250")
                                        hydration = recipe.optString("hydration", "62"); salt = recipe.optString("salt", "2.8")
                                        oil = recipe.optString("oil", "0"); yeast = recipe.optString("yeast", "0.10")
                                        hours = recipe.optString("hours", "24"); temp = recipe.optString("temp", "20")
                                        fridge = recipe.optBoolean("fridge", false)
                                        styleIndex = styles.indexOfFirst { it.name == recipe.optString("style") }.coerceAtLeast(0)
                                        recipeName = recipe.optString("name")
                                        tab = "Impasto"
                                        message = "Ricetta caricata"
                                    }) { Text("Carica") }
                                    OutlinedButton(onClick = {
                                        recipes = recipes.filterNot { it.optString("name") == recipe.optString("name") }
                                        saveRecipes(context, recipes)
                                        message = "Ricetta eliminata"
                                    }) { Text("Elimina") }
                                }
                            }
                        }
                    }
                    "Timer" -> {
                        CardBlock {
                            Text("Timer da cucina", fontSize = 21.sp, fontWeight = FontWeight.Black, color = red)
                            NumberField("Nome fase", timerLabel, { timerLabel = it })
                            NumberField("Durata in minuti", timerMinutes, { timerMinutes = it })
                            Text(formatTime(remaining), fontSize = 44.sp, fontWeight = FontWeight.Black, color = if (remaining > 0) red else ink)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = {
                                    val mins = (timerMinutes.toLongOrNull() ?: 30L).coerceIn(1L, 10080L)
                                    remaining = mins * 60L
                                    timerRunning = true
                                    message = ""
                                }, modifier = Modifier.weight(1f)) { Text("Avvia / Riavvia") }
                                OutlinedButton(onClick = { timerRunning = false }, modifier = Modifier.weight(1f)) { Text("Pausa") }
                                OutlinedButton(onClick = { timerRunning = false; remaining = 0L }, modifier = Modifier.weight(1f)) { Text("Azzera") }
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                listOf(10, 20, 30, 60).forEach { mins ->
                                    OutlinedButton(onClick = { timerMinutes = mins.toString(); remaining = mins * 60L; timerRunning = false }) { Text("${mins}m") }
                                }
                            }
                            Text("Il timer conta mentre l'app è aperta. Non invia notifiche se l'app viene chiusa.", fontSize = 12.sp, color = Color.Gray)
                        }
                    }
                    "DDT" -> {
                        CardBlock {
                            Text("Temperatura finale impasto (DDT)", fontSize = 21.sp, fontWeight = FontWeight.Black, color = red)
                            Text("Per un impasto diretto a tre fattori, una stima comune è: acqua = (3 × DDT desiderata) − temperatura farina − temperatura ambiente − fattore attrito.")
                            NumberField("DDT desiderata °C", targetDdt, { targetDdt = it })
                            NumberField("Temperatura farina °C", flourTemp, { flourTemp = it })
                            NumberField("Temperatura ambiente °C", roomTemp, { roomTemp = it })
                            NumberField("Fattore attrito °C", friction, { friction = it })
                            Divider()
                            Text("Temperatura acqua consigliata", fontSize = 14.sp, color = Color.Gray)
                            Text("${fmt(ddt)} °C", fontSize = 38.sp, fontWeight = FontWeight.Black, color = red)
                            Text("Formula semplificata a 3 fattori. Con prefermenti, impastatrici e metodi diversi il calcolo può cambiare; il fattore attrito va stimato per la propria attrezzatura.", fontSize = 12.sp, color = Color.Gray)
                        }
                    }
                }
            }
            NavigationBar(containerColor = Color.White) {
                listOf("Impasto", "Poolish", "Ricette", "Timer", "DDT").forEach { item ->
                    NavigationBarItem(
                        selected = tab == item, onClick = { tab = item },
                        icon = { Text(when (item) { "Impasto" -> "🍕"; "Poolish" -> "🧪"; "Ricette" -> "📖"; "Timer" -> "⏱"; else -> "🌡" }, fontSize = 18.sp) },
                        label = { Text(item, fontSize = 10.sp) }
                    )
                }
            }
        }
    }
}

@Composable
private fun CardBlock(content: @Composable ColumnScope.() -> Unit) {
    Card(shape = RoundedCornerShape(20.dp), colors = CardDefaults.cardColors(containerColor = cardColor), elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)) {
        Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(11.dp), content = content)
    }
}

@Composable
private fun NumberField(label: String, value: String, onValue: (String) -> Unit, modifier: Modifier = Modifier) {
    OutlinedTextField(
        value = value, onValueChange = onValue, label = { Text(label, fontSize = 12.sp) },
        modifier = modifier.fillMaxWidth(), singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = if (label.contains("Nome")) KeyboardType.Text else KeyboardType.Decimal),
        shape = RoundedCornerShape(12.dp)
    )
}

@Composable
private fun IngredientRow(name: String, grams: Float, detail: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Column(Modifier.weight(1f)) {
            Text(name, fontWeight = FontWeight.SemiBold)
            Text(detail, fontSize = 12.sp, color = Color.Gray)
        }
        Text("${fmt(grams)} g", fontWeight = FontWeight.Bold, fontSize = 16.sp)
    }
}

@Composable
private fun SimpleDropdown(value: String, options: List<String>, onPick: (String) -> Unit) {
    var expanded by remember { mutableStateOf(false) }
    Box {
        OutlinedButton(onClick = { expanded = true }) { Text("$value  ▾") }
        DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
            options.forEach { option -> DropdownMenuItem(text = { Text(option) }, onClick = { onPick(option); expanded = false }) }
        }
    }
}

private fun fmt(v: Float): String = String.format(Locale.ITALY, "%.1f", if (v.isFinite()) v else 0f)
private fun formatTime(seconds: Long): String {
    val s = seconds.coerceAtLeast(0L)
    return String.format(Locale.ITALY, "%02d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
}
private fun loadRecipes(context: Context): List<JSONObject> {
    return try {
        val raw = context.getSharedPreferences("dough_pizza", Context.MODE_PRIVATE).getString("recipes", "[]") ?: "[]"
        val arr = JSONArray(raw)
        (0 until arr.length()).map { arr.getJSONObject(it) }
    } catch (_: Exception) { emptyList() }
}
private fun saveRecipes(context: Context, recipes: List<JSONObject>) {
    val arr = JSONArray()
    recipes.forEach { arr.put(it) }
    context.getSharedPreferences("dough_pizza", Context.MODE_PRIVATE).edit().putString("recipes", arr.toString()).apply()
}
